import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { mergeMap } from 'rxjs';

import { TranslateDirective } from 'app/shared/language';

import { ActivateService } from './activate.service';

@Component({
  selector: 'jhi-activate',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, TranslateDirective],
  templateUrl: './activate.html',
})
export default class Activate implements OnInit {
  readonly error = signal(false);
  readonly success = signal(false);

  private readonly activateService = inject(ActivateService);
  private readonly route = inject(ActivatedRoute);

  ngOnInit(): void {
    this.route.queryParams.pipe(mergeMap(params => this.activateService.get(params.key))).subscribe({
      next: () => this.success.set(true),
      error: () => this.error.set(true),
    });
  }
}
