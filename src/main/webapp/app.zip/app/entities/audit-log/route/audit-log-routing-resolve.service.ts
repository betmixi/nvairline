import { HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, Router } from '@angular/router';

import { EMPTY, Observable, catchError, of } from 'rxjs';

import { IAuditLog } from '../audit-log.model';
import { AuditLogService } from '../service/audit-log.service';

const auditLogResolve = (route: ActivatedRouteSnapshot): Observable<null | IAuditLog> => {
  const { id } = route.params;
  if (id) {
    const router = inject(Router);
    const service = inject(AuditLogService);
    return service.find(id).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 404) {
          router.navigate(['404']);
        } else {
          router.navigate(['error']);
        }
        return EMPTY;
      }),
    );
  }

  return of(null);
};

export default auditLogResolve;
